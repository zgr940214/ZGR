#define UTS_RELEASE "6.12.93-v8"
